# This file is generated before each commit
FRAMEWORK_VERSION = "0.1-r402"
